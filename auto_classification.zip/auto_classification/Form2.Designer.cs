﻿namespace auto_classification
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_after = new System.Windows.Forms.Button();
            this.cboListViewMode = new System.Windows.Forms.ComboBox();
            this.txtCurPath = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btn_back);
            this.splitContainer1.Panel2.Controls.Add(this.btn_after);
            this.splitContainer1.Panel2.Controls.Add(this.cboListViewMode);
            this.splitContainer1.Panel2.Controls.Add(this.txtCurPath);
            this.splitContainer1.Panel2.Controls.Add(this.listView1);
            this.splitContainer1.Size = new System.Drawing.Size(1083, 509);
            this.splitContainer1.SplitterDistance = 271;
            this.splitContainer1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9F);
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select folder\r\n";
            // 
            // treeView1
            // 
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(3, 55);
            this.treeView1.Name = "treeView1";
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(265, 442);
            this.treeView1.TabIndex = 0;
            this.treeView1.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView1_BeforeCollapse);
            this.treeView1.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView1_BeforeExpand);
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "hard_drive_windows_2.ico");
            this.imageList1.Images.SetKeyName(1, "hard_drive.ico");
            this.imageList1.Images.SetKeyName(2, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(3, "opened_folder.ico");
            this.imageList1.Images.SetKeyName(4, "Hopstarter-Sleek-Xp_Basic-Document-Blank.ico");
            // 
            // btn_back
            // 
            this.btn_back.Image = global::auto_classification.Properties.Resources.go_after1;
            this.btn_back.Location = new System.Drawing.Point(8, 19);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(29, 20);
            this.btn_back.TabIndex = 9;
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_after
            // 
            this.btn_after.Image = global::auto_classification.Properties.Resources.go_after;
            this.btn_after.Location = new System.Drawing.Point(40, 19);
            this.btn_after.Name = "btn_after";
            this.btn_after.Size = new System.Drawing.Size(29, 20);
            this.btn_after.TabIndex = 8;
            this.btn_after.UseVisualStyleBackColor = true;
            this.btn_after.Click += new System.EventHandler(this.btn_after_Click);
            // 
            // cboListViewMode
            // 
            this.cboListViewMode.FormattingEnabled = true;
            this.cboListViewMode.Location = new System.Drawing.Point(623, 19);
            this.cboListViewMode.Name = "cboListViewMode";
            this.cboListViewMode.Size = new System.Drawing.Size(182, 20);
            this.cboListViewMode.TabIndex = 7;
            this.cboListViewMode.SelectedIndexChanged += new System.EventHandler(this.cboListViewMode_SelectedIndexChanged);
            // 
            // txtCurPath
            // 
            this.txtCurPath.Location = new System.Drawing.Point(73, 19);
            this.txtCurPath.Name = "txtCurPath";
            this.txtCurPath.ReadOnly = true;
            this.txtCurPath.Size = new System.Drawing.Size(544, 21);
            this.txtCurPath.TabIndex = 6;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.LargeImageList = this.imageList2;
            this.listView1.Location = new System.Drawing.Point(3, 55);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(802, 442);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.Click += new System.EventHandler(this.listView1_Click);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "hard_drive_windows_2.ico");
            this.imageList2.Images.SetKeyName(1, "hard_drive.ico");
            this.imageList2.Images.SetKeyName(2, "folderopened_yellow.ico");
            this.imageList2.Images.SetKeyName(3, "opened_folder.ico");
            this.imageList2.Images.SetKeyName(4, "Hopstarter-Sleek-Xp_Basic-Document-Blank.ico");
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 509);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_after;
        private System.Windows.Forms.ComboBox cboListViewMode;
        private System.Windows.Forms.TextBox txtCurPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageList2;
    }
}