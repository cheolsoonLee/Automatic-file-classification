﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace auto_classification
{
    public partial class Form1 : Form
    {

        //최상위 계층인 드라이브를 넣어줄 root_node
        TreeNode root_node;

        //path list를 넣어줄 linked list
        LinkedList<String> path_list = new LinkedList<string>();
        LinkedListNode<String> head_node;
        LinkedListNode<string> tail_node = null;

        LinkedListNode<String> cur_node;
        LinkedListNode<String> pre_node;
        LinkedListNode<String> aft_node;

        //트리뷰 클릭 수
        int time = 0;
        //뒤로가기 버튼 클릭 유무
        int clicked_btn_back = 0;

        //현재 path
        String cur_path;
        //이전 path
        String previous_path;
        

        public Form1()
        {
            InitializeComponent();

            //보기 옵션 콤보 설정

            cboListViewMode.DropDownStyle = ComboBoxStyle.DropDownList;
            cboListViewMode.Items.Add("Details");
            cboListViewMode.Items.Add("SmallIcon");
            cboListViewMode.Items.Add("LargeIcon");
            cboListViewMode.Items.Add("List");
            cboListViewMode.Items.Add("Tile");
            cboListViewMode.SelectedIndex = 0;
            
            
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            //현재 사용자 정보 표시
            System.Security.Principal.WindowsIdentity identity = System.Security.Principal.WindowsIdentity.GetCurrent();
            label1.Text = "현재 사용자: " + identity.Name;

            //현재 로컬 컴퓨터에 존재하는 드라이브 정보 검색하여 트리노드에 추가
            DriveInfo[] allDrives = DriveInfo.GetDrives();

            foreach (DriveInfo dname in allDrives)
            {
                if (dname.DriveType == DriveType.Fixed)
                {
                    if (dname.Name == @"C:\")
                    {
                        TreeNode rootNode = new TreeNode(dname.Name);
                        rootNode.ImageIndex = 1;
                        rootNode.SelectedImageIndex = 1;
                        root_node = rootNode;
                        treeView1.Nodes.Add(rootNode);
                        
                        Fill(rootNode);
                    }
                    else
                    {
                        TreeNode rootNode = new TreeNode(dname.Name);
                        rootNode.ImageIndex = 1;
                        rootNode.SelectedImageIndex = 1;
                        root_node = rootNode;
                        treeView1.Nodes.Add(rootNode);
                        Fill(rootNode);
                    }
                }
            }

            //첫번쨰 노드 확장
            treeView1.Nodes[0].Expand();

            //ListView보기 속성 설정
            //listView1.View = View.Details;

            //ListView Detatils 속성을 위한 헤더 추가
            listView1.Columns.Add("이름", listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("수정한 날짜", listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("유형", listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("크기", listView1.Width / 4, HorizontalAlignment.Left);

            //행 단위 선택가능
            listView1.FullRowSelect = true;
        }

        //트리노드에 디렉토리 정보 채우기
        private void Fill(TreeNode dirNode)
        {
            try
            { 
                DirectoryInfo dir = new DirectoryInfo(dirNode.FullPath);


                //드라이브의 하위 폴더 추가
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {
                    //폴더 및 파일이 숨김파일이 아닌 경우
                    if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        TreeNode newNode = new TreeNode(dirItem.Name);
                        newNode.ImageIndex = 2;
                        newNode.SelectedImageIndex = 2;
                        dirNode.Nodes.Add(newNode);
                        newNode.Nodes.Add("*");
                        
                    }
                    //폴더 및 파일이 숨김파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("에러발생 : " + ex.Message);
            }
        }

        private void treeView1_BeforeExpand_1(object sender, TreeViewCancelEventArgs e)
        {
            
            //드라이브가 아닐 경우 imageIndex 3으로 변환
            if (e.Node != root_node)
            {
                e.Node.ImageIndex = 3;
                e.Node.SelectedImageIndex = 3;
            }

            if (e.Node.Nodes[0].Text == "*")
            {
                
                e.Node.Nodes.Clear();       
                Fill(e.Node);
            }
        }

        private void treeView1_BeforeCollapse_1(object sender, TreeViewCancelEventArgs e)
        {

            e.Node.ImageIndex = 2;
            e.Node.SelectedImageIndex = 2;
        }

        private void treeView1_NodeMouseClick_1(object sender, TreeNodeMouseClickEventArgs e)
        {
            try
            {
                //기존의 파일 목록 제거
                listView1.Items.Clear();

                //현재 경로를 표시
                txtCurPath.Text = e.Node.FullPath;

                //path_리스트에 현재 path를 넣어준다
                path_list.AddLast(txtCurPath.Text);

                //맨 처음 트리뷰에서 폴더를 선택했을 경우
                if (time == 0)
                {
                    head_node = path_list.Find(txtCurPath.Text);
                    cur_node = head_node;
                    time++;
                }

                else
                {
                    pre_node = cur_node;
                    find_last_node(path_list, head_node);
                    cur_node = tail_node;
                }

                //트리뷰의 상위폴더 경로를 넣어준다
                cur_path = txtCurPath.Text;

                DirectoryInfo dir = new DirectoryInfo(e.Node.FullPath);

                int DirectCount = 0;
                //하부 디렉토리 보여주기
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {

                    //숨김 파일이 아닌경우
                    if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        //하부 디렉토리가 존재할 경우 ListView에 추가
                        //ListViewItem 객체를 생성
                        ListViewItem lsvitem = new ListViewItem();

                        //생성된 ListViewItem 객체에 똑같은 이미지를 할당
                        lsvitem.ImageIndex = 2;
                        lsvitem.Text = dirItem.Name;

                        //아이템을 ListView(listView1)에 추가
                        listView1.Items.Add(lsvitem);

                        listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                        listView1.Items[DirectCount].SubItems.Add("폴더");
                        listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + "files");

                        DirectCount++;
                    }

                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }

                   
                }

                //디렉토리에 존재하는 파일목록 보여주기
                FileInfo[] files = dir.GetFiles();
                int Count = 0;
                foreach (FileInfo fileinfo in files)
                {

                    //숨겨진 파일이 아닌 경우
                    if((fileinfo.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        ListViewItem lsvitem = new ListViewItem();
                        lsvitem.ImageIndex = 4;
                        lsvitem.Text = fileinfo.Name;
                        listView1.Items.Add(lsvitem);


                        if (fileinfo.LastWriteTime != null)
                        {
                            listView1.Items[Count].SubItems.Add(fileinfo.LastWriteTime.ToString());
                        }
                        else
                        {
                            listView1.Items[Count].SubItems.Add(fileinfo.CreationTime.ToString());
                        }
                        listView1.Items[Count].SubItems.Add(fileinfo.Attributes.ToString());
                        listView1.Items[Count].SubItems.Add(fileinfo.Length.ToString());
                        Count++;
                    }

                    //숨겨진 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }

                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("에러발생 : " + ex.Message);
            }
            
            //treeView1.Nodes[0].Expand();

        }

        private void listView1_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {

            if (this.listView1.SelectedItems.Count != 0)
            {            
                String folder_name = this.listView1.SelectedItems[0].Text;
                String path = cur_path + "\\" + folder_name;

                txtCurPath.Text = path;

                path_list.AddLast(path);

                find_last_node(path_list, head_node);

                pre_node = cur_node;
                cur_node = tail_node;

                cur_path = path;
                    
                //기존의 파일 목록 제거
                listView1.Items.Clear();

                try
                {

                    //선택한 것의 경로 찾기 해야한다
                    DirectoryInfo dir = new DirectoryInfo(path);

                    int DirectCount = 0;

                    //하부 디렉토리 보여주기
                    foreach (DirectoryInfo dirItem in dir.GetDirectories())
                    {

                        //숨김 파일이 아닌 경우
                        if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            //하부 디렉토리가 존재할 경우 ListView에 추가
                            //ListViewItem 객체를 생성
                            ListViewItem lsvitem = new ListViewItem();

                            //생성된 ListviewItem 객체에 똑같은 이미지를 할당
                            lsvitem.ImageIndex = 2;
                            lsvitem.Text = dirItem.Name;

                            //아이템을 ListView(listView1)에 추가하기
                            listView1.Items.Add(lsvitem);
                            //listView1.Items.Add(dirItem.Name);

                            listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                            listView1.Items[DirectCount].SubItems.Add("폴더");
                            listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + " files");
                            DirectCount++;
                        }

                        //숨김 파일인 경우 보여주지 않는다
                        else
                        {
                            continue;
                        }
                       
                    }

                    FileInfo[] fishow = dir.GetFiles();
                    int Count = 0;
                    foreach (FileInfo fri in fishow)
                    {

                        //숨김 파일이 아닌 경우
                        if((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            listView1.Items.Add(fri.Name);
                            if (fri.LastAccessTime.ToString() != null)
                            {
                                listView1.Items[Count].SubItems.Add(fri.LastWriteTime.ToString());
                            }
                            else
                            {
                                listView1.Items[Count].SubItems.Add(fri.CreationTime.ToString());
                            }
                            listView1.Items[Count].SubItems.Add(fri.Attributes.ToString());
                            listView1.Items[Count].SubItems.Add(fri.Length.ToString());
                            Count++;
                        }

                        //숨김 파일인 경우 보여주지 않는다
                        else
                        {
                            continue;
                        }
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("예외 발생 : " + ex.Message);
                }
            }

            
        }

        private void cboListViewMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(cboListViewMode.Text)
            {
                case "Details":
                    listView1.View = View.Details;
                    break;

                case "SmallIcon":
                    listView1.View = View.SmallIcon;
                    break;

                case "LargeIcon":
                    listView1.View = View.LargeIcon;
                    break;

                case "List":
                    listView1.View = View.List;
                    break;

                case "Tile":
                    listView1.View = View.Tile;
                    break;
            }
        }


        private void btn_back_Click(object sender, EventArgs e)
        {
            clicked_btn_back = 1;

            find_last_node(path_list, head_node);

            
            if(pre_node == null && cur_node == tail_node)
            {
                //폴더를 처음 한번 클릭했을 경우 -> 이 경우는 뒤로가기 할 곳이 없으므로 어떤 행동도 취하지 않느다
            }

            //뒤로 가기 할 경우가 있을 경우
            else
            {
                //currnet node가 head 노드에 위치할 때
                if(cur_node.Previous == null)
                {
                    //이 경우에도 뒤로 갈 곳이 없으므로 어떤 행동도 취하지 않는다
                }

                else
                {
                    //기존의 파일 목록 제거
                    listView1.Items.Clear();

                    Console.WriteLine(cur_path);

                    if (pre_node == null)
                    {
                        aft_node = cur_node;
                        cur_node = cur_node.Previous;
                        cur_path = cur_node.Value;
                        txtCurPath.Text = cur_path;
                    }

                    else
                    {
                        aft_node = cur_node;
                        cur_node = pre_node;
                        cur_path = cur_node.Value;
                        pre_node = null;
                        txtCurPath.Text = cur_path;
                    }

                    try
                    {

                       

                        //선택한 것의 경로 찾기 해야한다
                        DirectoryInfo dir = new DirectoryInfo(cur_node.Value);

                        int DirectCount = 0;

                        //하부 디렉토리 보여주기
                        foreach (DirectoryInfo dirItem in dir.GetDirectories())
                        {
                            //숨김 파일이 아닌 경우
                            if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                //하부 디렉토리가 존재할 경우 ListView에 추가
                                //ListViewItem 객체를 생성
                                ListViewItem lsvitem = new ListViewItem();

                                //생성된 ListviewItem 객체에 똑같은 이미지를 할당
                                lsvitem.ImageIndex = 2;
                                lsvitem.Text = dirItem.Name;

                                //아이템을 ListView(listView1)에 추가하기
                                listView1.Items.Add(lsvitem);
                                //listView1.Items.Add(dirItem.Name);

                                listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                                listView1.Items[DirectCount].SubItems.Add("폴더");
                                listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + " files");
                                DirectCount++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }
                            
                        }

                        FileInfo[] fishow = dir.GetFiles();
                        int Count = 0;
                        foreach (FileInfo fri in fishow)
                        {

                            //숨김 파일이 아닌 경우
                            if((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                listView1.Items.Add(fri.Name);
                                if (fri.LastAccessTime.ToString() != null)
                                {
                                    listView1.Items[Count].SubItems.Add(fri.LastWriteTime.ToString());
                                }
                                else
                                {
                                    listView1.Items[Count].SubItems.Add(fri.CreationTime.ToString());
                                }
                                listView1.Items[Count].SubItems.Add(fri.Attributes.ToString());
                                listView1.Items[Count].SubItems.Add(fri.Length.ToString());
                                Count++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }                   
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("예외 발생 : " + ex.Message);
                    }

                }

                

            }


        }

        private void btn_after_Click(object sender, EventArgs e)
        {

            //뒤로가기를 누르지 않은 경우
            if (clicked_btn_back == 0)
            {
                //아무 행동도 취하지 않는다
            }

            //뒤로 가기를 한번 이라도 누른 경우
            else
            {
                //current node가 tail에 위치 할 경우
                if (cur_node.Next == null)
                {
                    //아무 행동도 취하지 않는다
                }

                //current node가 tail이 아니라 더 이동 할 수 있는 경우
                else
                {
                    //이미 한번 이동하였고, 또 이동하려는 경우
                    if (aft_node == null)
                    {
                        cur_node = cur_node.Next;
                        cur_path = cur_node.Value;
                        txtCurPath.Text = cur_path;
                    }

                    //첫 이동일 경우
                    else
                    {
                        pre_node = cur_node;
                        cur_node = aft_node;
                        cur_path = cur_node.Value;
                        txtCurPath.Text = cur_path;
                        aft_node = null;
                    }

                    try
                    {
                        //기존의 파일 목록 제거
                        listView1.Items.Clear();

                        //선택한 것의 경로 찾기 해야한다
                        DirectoryInfo dir = new DirectoryInfo(cur_node.Value);

                        int DirectCount = 0;

                        //하부 디렉토리 보여주기
                        foreach (DirectoryInfo dirItem in dir.GetDirectories())
                        {
                            //숨김 파일이 아닌 경우
                            if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                //하부 디렉토리가 존재할 경우 ListView에 추가
                                //ListViewItem 객체를 생성
                                ListViewItem lsvitem = new ListViewItem();

                                //생성된 ListviewItem 객체에 똑같은 이미지를 할당
                                lsvitem.ImageIndex = 2;
                                lsvitem.Text = dirItem.Name;

                                //아이템을 ListView(listView1)에 추가하기
                                listView1.Items.Add(lsvitem);
                                //listView1.Items.Add(dirItem.Name);

                                listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                                listView1.Items[DirectCount].SubItems.Add("폴더");
                                listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + " files");
                                DirectCount++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }

                            
                        }

                        //모든 파일을 가져온다
                        FileInfo[] fishow = dir.GetFiles();
                        int Count = 0;
                        foreach (FileInfo fri in fishow)
                        {

                            //숨김 파일이 아닌 경우
                            if((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                listView1.Items.Add(fri.Name);
                                if (fri.LastAccessTime.ToString() != null)
                                {
                                    listView1.Items[Count].SubItems.Add(fri.LastWriteTime.ToString());
                                }
                                else
                                {
                                    listView1.Items[Count].SubItems.Add(fri.CreationTime.ToString());
                                }
                                listView1.Items[Count].SubItems.Add(fri.Attributes.ToString());
                                listView1.Items[Count].SubItems.Add(fri.Length.ToString());
                                Count++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }

                            
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("예외 발생 : " + ex.Message);
                    }


                }
            }
        
        }

        //list의 tail을 찾아낸다
        private void find_last_node(LinkedList<String> path_list, LinkedListNode<String> head)
        {
            LinkedListNode<String> current = head;

            while(current.Next != null)
            {
                current = current.Next;
            }
            tail_node = current;
        }
        private void button1_Click(object sender, EventArgs e)

        {

        }
    }
}
