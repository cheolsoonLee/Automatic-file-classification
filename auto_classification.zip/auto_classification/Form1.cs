﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace auto_classification
{
    public partial class Form1 : Form
    {

        //최상위 계층인 드라이브를 넣어줄 root_node
        TreeNode root_node;

        //path list를 넣어줄 linked list
        LinkedList<String> path_list = new LinkedList<string>();
        LinkedListNode<String> head_node;
        LinkedListNode<string> tail_node = null;

        LinkedListNode<String> cur_node;
        LinkedListNode<String> pre_node;
        LinkedListNode<String> aft_node;

        //트리뷰 클릭 수
        int time = 0;
        //뒤로가기 버튼 클릭 유무
        int clicked_btn_back = 0;

        //현재 path
        String cur_path;

        //현재 순위 창
        //ex) 1~3순위 : 1, 4~6순위 : 2 ...
        int rank_window = 1;

            
        //폴더에서 파일이나 폴더의 이름을 단어로 쪼개서 넣어줄 dictionary
        //string : 단어 / int : 횟수
        Dictionary<String, int> dict_word_list = new Dictionary<string, int>();

        //정렬된 dictionary -> 단어가 나온 횟수 내림차순
        Dictionary<String, int> sorted_list = new Dictionary<string, int>();

        public Form1()
        {
            InitializeComponent();

            //보기 옵션 콤보 설정

            cboListViewMode.DropDownStyle = ComboBoxStyle.DropDownList;
            cboListViewMode.Items.Add("Details");
            cboListViewMode.Items.Add("SmallIcon");
            cboListViewMode.Items.Add("LargeIcon");
            cboListViewMode.Items.Add("List");
            cboListViewMode.Items.Add("Tile");
            cboListViewMode.SelectedIndex = 0;
            
            
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            //현재 사용자 정보 표시
            System.Security.Principal.WindowsIdentity identity = System.Security.Principal.WindowsIdentity.GetCurrent();
            label1.Text = "현재 사용자: " + identity.Name;

            //현재 로컬 컴퓨터에 존재하는 드라이브 정보 검색하여 트리노드에 추가
            DriveInfo[] allDrives = DriveInfo.GetDrives();

            foreach (DriveInfo dname in allDrives)
            {
                if (dname.DriveType == DriveType.Fixed)
                {
                    if (dname.Name == @"C:\")
                    {
                        TreeNode rootNode = new TreeNode(dname.Name);
                        rootNode.ImageIndex = 1;
                        rootNode.SelectedImageIndex = 1;
                        root_node = rootNode;
                        treeView1.Nodes.Add(rootNode);
                        
                        Fill(rootNode);
                    }
                    else
                    {
                        TreeNode rootNode = new TreeNode(dname.Name);
                        rootNode.ImageIndex = 1;
                        rootNode.SelectedImageIndex = 1;
                        root_node = rootNode;
                        treeView1.Nodes.Add(rootNode);
                        Fill(rootNode);
                    }
                }
            }

            //첫번쨰 노드 확장
            treeView1.Nodes[0].Expand();

            //ListView보기 속성 설정
            //listView1.View = View.Details;

            //ListView Detatils 속성을 위한 헤더 추가
            listView1.Columns.Add("이름", listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("수정한 날짜", listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("유형", listView1.Width / 4, HorizontalAlignment.Left);
            listView1.Columns.Add("크기", listView1.Width / 4, HorizontalAlignment.Left);

            //행 단위 선택가능
            listView1.FullRowSelect = true;
        }

        //트리노드에 디렉토리 정보 채우기
        private void Fill(TreeNode dirNode)
        {
            try
            { 
                DirectoryInfo dir = new DirectoryInfo(dirNode.FullPath);


                //드라이브의 하위 폴더 추가
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {
                    //폴더 및 파일이 숨김파일이 아닌 경우
                    if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        TreeNode newNode = new TreeNode(dirItem.Name);
                        newNode.ImageIndex = 2;
                        newNode.SelectedImageIndex = 2;
                        dirNode.Nodes.Add(newNode);
                        newNode.Nodes.Add("*");
                        
                    }
                    //폴더 및 파일이 숨김파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("에러발생 : " + ex.Message);
            }
        }

        private void treeView1_BeforeExpand_1(object sender, TreeViewCancelEventArgs e)
        {
            
            //드라이브가 아닐 경우 imageIndex 3으로 변환
            if (e.Node != root_node)
            {
                e.Node.ImageIndex = 3;
                e.Node.SelectedImageIndex = 3;
            }

            if (e.Node.Nodes[0].Text == "*")
            {
                
                e.Node.Nodes.Clear();       
                Fill(e.Node);
            }
        }

        private void treeView1_BeforeCollapse_1(object sender, TreeViewCancelEventArgs e)
        {

            e.Node.ImageIndex = 2;
            e.Node.SelectedImageIndex = 2;
        }

        private void treeView1_NodeMouseClick_1(object sender, TreeNodeMouseClickEventArgs e)
        {
            try
            {
                //기존의 파일 목록 제거
                listView1.Items.Clear();

                //현재 경로를 표시
                txtCurPath.Text = e.Node.FullPath;

                //path_리스트에 현재 path를 넣어준다
                path_list.AddLast(txtCurPath.Text);

                //맨 처음 트리뷰에서 폴더를 선택했을 경우
                if (time == 0)
                {
                    head_node = path_list.Find(txtCurPath.Text);
                    cur_node = head_node;
                    time++;
                }

                else
                {
                    pre_node = cur_node;
                    find_last_node(path_list, head_node);
                    cur_node = tail_node;
                }

                //트리뷰의 상위폴더 경로를 넣어준다
                cur_path = txtCurPath.Text;

                //location textbox에 선택 되어진 폴더의 위치를 지속적으로 갱신시켜준다
                txt_location.Text = cur_path;

                DirectoryInfo dir = new DirectoryInfo(e.Node.FullPath);

                int DirectCount = 0;
                //하부 디렉토리 보여주기
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {

                    //숨김 파일이 아닌경우
                    if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        //하부 디렉토리가 존재할 경우 ListView에 추가
                        //ListViewItem 객체를 생성
                        ListViewItem lsvitem = new ListViewItem();

                        //생성된 ListViewItem 객체에 똑같은 이미지를 할당
                        lsvitem.ImageIndex = 2;
                        lsvitem.Text = dirItem.Name;

                        //아이템을 ListView(listView1)에 추가
                        listView1.Items.Add(lsvitem);

                        listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                        listView1.Items[DirectCount].SubItems.Add("폴더");
                        listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + "files");

                        DirectCount++;
                    }

                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }

                   
                }

                //디렉토리에 존재하는 파일목록 보여주기
                FileInfo[] files = dir.GetFiles();
                int Count = 0;
                foreach (FileInfo fileinfo in files)
                {

                    //숨겨진 파일이 아닌 경우
                    if((fileinfo.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        ListViewItem lsvitem = new ListViewItem();
                        lsvitem.ImageIndex = 4;
                        lsvitem.Text = fileinfo.Name;
                        listView1.Items.Add(lsvitem);


                        if (fileinfo.LastWriteTime != null)
                        {
                            listView1.Items[Count].SubItems.Add(fileinfo.LastWriteTime.ToString());
                        }
                        else
                        {
                            listView1.Items[Count].SubItems.Add(fileinfo.CreationTime.ToString());
                        }
                        listView1.Items[Count].SubItems.Add(fileinfo.Attributes.ToString());
                        listView1.Items[Count].SubItems.Add(fileinfo.Length.ToString());
                        Count++;
                    }

                    //숨겨진 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }

                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("에러발생 : " + ex.Message);
            }
            
            //treeView1.Nodes[0].Expand();

        }

        private void listView1_Click(object sender, EventArgs e)
        {
            if (this.listView1.SelectedItems.Count != 0)
            {
                String folder_name2 = this.listView1.SelectedItems[0].Text;
                String path2 = cur_path + "\\" + folder_name2;
            
                //location textbox에 선택 되어진 폴더의 위치를 지속적으로 갱신시켜준다
                txt_location.Text = path2;
            }

            }

        private void listView1_MouseDoubleClick_1(object sender, MouseEventArgs e)
        {

            if (this.listView1.SelectedItems.Count != 0)
            {            
                String folder_name = this.listView1.SelectedItems[0].Text;
                String path = cur_path + "\\" + folder_name;

                txtCurPath.Text = path;

                path_list.AddLast(path);

                find_last_node(path_list, head_node);

                pre_node = cur_node;
                cur_node = tail_node;

                cur_path = path;

                
                    
                //기존의 파일 목록 제거
                listView1.Items.Clear();

                try
                {

                    //선택한 것의 경로 찾기 해야한다
                    DirectoryInfo dir = new DirectoryInfo(path);

                    int DirectCount = 0;

                    //하부 디렉토리 보여주기
                    foreach (DirectoryInfo dirItem in dir.GetDirectories())
                    {

                        //숨김 파일이 아닌 경우
                        if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            //하부 디렉토리가 존재할 경우 ListView에 추가
                            //ListViewItem 객체를 생성
                            ListViewItem lsvitem = new ListViewItem();

                            //생성된 ListviewItem 객체에 똑같은 이미지를 할당
                            lsvitem.ImageIndex = 2;
                            lsvitem.Text = dirItem.Name;

                            //아이템을 ListView(listView1)에 추가하기
                            listView1.Items.Add(lsvitem);
                            //listView1.Items.Add(dirItem.Name);

                            listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                            listView1.Items[DirectCount].SubItems.Add("폴더");
                            listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + " files");
                            DirectCount++;
                        }

                        //숨김 파일인 경우 보여주지 않는다
                        else
                        {
                            continue;
                        }
                       
                    }

                    FileInfo[] fishow = dir.GetFiles();
                    int Count = 0;
                    foreach (FileInfo fri in fishow)
                    {

                        //숨김 파일이 아닌 경우
                        if((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            listView1.Items.Add(fri.Name);
                            if (fri.LastAccessTime.ToString() != null)
                            {
                                listView1.Items[Count].SubItems.Add(fri.LastWriteTime.ToString());
                            }
                            else
                            {
                                listView1.Items[Count].SubItems.Add(fri.CreationTime.ToString());
                            }
                            listView1.Items[Count].SubItems.Add(fri.Attributes.ToString());
                            listView1.Items[Count].SubItems.Add(fri.Length.ToString());
                            Count++;
                        }

                        //숨김 파일인 경우 보여주지 않는다
                        else
                        {
                            continue;
                        }
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("예외 발생 : " + ex.Message);
                }
            }

            
        }

        private void cboListViewMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(cboListViewMode.Text)
            {
                case "Details":
                    listView1.View = View.Details;
                    break;

                case "SmallIcon":
                    listView1.View = View.SmallIcon;
                    break;

                case "LargeIcon":
                    listView1.View = View.LargeIcon;
                    break;

                case "List":
                    listView1.View = View.List;
                    break;

                case "Tile":
                    listView1.View = View.Tile;
                    break;
            }
        }


        private void btn_back_Click(object sender, EventArgs e)
        {
            clicked_btn_back = 1;

            find_last_node(path_list, head_node);

            
            if(pre_node == null && cur_node == tail_node)
            {
                //폴더를 처음 한번 클릭했을 경우 -> 이 경우는 뒤로가기 할 곳이 없으므로 어떤 행동도 취하지 않느다
            }

            //뒤로 가기 할 경우가 있을 경우
            else
            {
                //currnet node가 head 노드에 위치할 때
                if(cur_node.Previous == null)
                {
                    //이 경우에도 뒤로 갈 곳이 없으므로 어떤 행동도 취하지 않는다
                }

                else
                {
                    //기존의 파일 목록 제거
                    listView1.Items.Clear();

                    if (pre_node == null)
                    {
                        aft_node = cur_node;
                        cur_node = cur_node.Previous;
                        cur_path = cur_node.Value;
                        txtCurPath.Text = cur_path;
                    }

                    else
                    {
                        aft_node = cur_node;
                        cur_node = pre_node;
                        cur_path = cur_node.Value;
                        pre_node = null;
                        txtCurPath.Text = cur_path;
                    }

                    try
                    {

                       

                        //선택한 것의 경로 찾기 해야한다
                        DirectoryInfo dir = new DirectoryInfo(cur_node.Value);

                        int DirectCount = 0;

                        //하부 디렉토리 보여주기
                        foreach (DirectoryInfo dirItem in dir.GetDirectories())
                        {
                            //숨김 파일이 아닌 경우
                            if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                //하부 디렉토리가 존재할 경우 ListView에 추가
                                //ListViewItem 객체를 생성
                                ListViewItem lsvitem = new ListViewItem();

                                //생성된 ListviewItem 객체에 똑같은 이미지를 할당
                                lsvitem.ImageIndex = 2;
                                lsvitem.Text = dirItem.Name;

                                //아이템을 ListView(listView1)에 추가하기
                                listView1.Items.Add(lsvitem);
                                //listView1.Items.Add(dirItem.Name);

                                listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                                listView1.Items[DirectCount].SubItems.Add("폴더");
                                listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + " files");
                                DirectCount++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }
                            
                        }

                        FileInfo[] fishow = dir.GetFiles();
                        int Count = 0;
                        foreach (FileInfo fri in fishow)
                        {

                            //숨김 파일이 아닌 경우
                            if((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                listView1.Items.Add(fri.Name);
                                if (fri.LastAccessTime.ToString() != null)
                                {
                                    listView1.Items[Count].SubItems.Add(fri.LastWriteTime.ToString());
                                }
                                else
                                {
                                    listView1.Items[Count].SubItems.Add(fri.CreationTime.ToString());
                                }
                                listView1.Items[Count].SubItems.Add(fri.Attributes.ToString());
                                listView1.Items[Count].SubItems.Add(fri.Length.ToString());
                                Count++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }                   
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("예외 발생 : " + ex.Message);
                    }

                }

            }

        }

        private void btn_after_Click(object sender, EventArgs e)
        {

            //뒤로가기를 누르지 않은 경우
            if (clicked_btn_back == 0)
            {
                //아무 행동도 취하지 않는다
            }

            //뒤로 가기를 한번 이라도 누른 경우
            else
            {
                //current node가 tail에 위치 할 경우
                if (cur_node.Next == null)
                {
                    //아무 행동도 취하지 않는다
                }

                //current node가 tail이 아니라 더 이동 할 수 있는 경우
                else
                {
                    //이미 한번 이동하였고, 또 이동하려는 경우
                    if (aft_node == null)
                    {
                        cur_node = cur_node.Next;
                        cur_path = cur_node.Value;
                        txtCurPath.Text = cur_path;
                    }

                    //첫 이동일 경우
                    else
                    {
                        pre_node = cur_node;
                        cur_node = aft_node;
                        cur_path = cur_node.Value;
                        txtCurPath.Text = cur_path;
                        aft_node = null;
                    }

                    try
                    {
                        //기존의 파일 목록 제거
                        listView1.Items.Clear();

                        //선택한 것의 경로 찾기 해야한다
                        DirectoryInfo dir = new DirectoryInfo(cur_node.Value);

                        int DirectCount = 0;

                        //하부 디렉토리 보여주기
                        foreach (DirectoryInfo dirItem in dir.GetDirectories())
                        {
                            //숨김 파일이 아닌 경우
                            if((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                //하부 디렉토리가 존재할 경우 ListView에 추가
                                //ListViewItem 객체를 생성
                                ListViewItem lsvitem = new ListViewItem();

                                //생성된 ListviewItem 객체에 똑같은 이미지를 할당
                                lsvitem.ImageIndex = 2;
                                lsvitem.Text = dirItem.Name;

                                //아이템을 ListView(listView1)에 추가하기
                                listView1.Items.Add(lsvitem);
                                //listView1.Items.Add(dirItem.Name);

                                listView1.Items[DirectCount].SubItems.Add(dirItem.CreationTime.ToString());
                                listView1.Items[DirectCount].SubItems.Add("폴더");
                                listView1.Items[DirectCount].SubItems.Add(dirItem.GetFiles().Length.ToString() + " files");
                                DirectCount++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }
                     
                        }

                        //모든 파일을 가져온다
                        FileInfo[] fishow = dir.GetFiles();
                        int Count = 0;
                        foreach (FileInfo fri in fishow)
                        {

                            //숨김 파일이 아닌 경우
                            if((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                            {
                                listView1.Items.Add(fri.Name);
                                if (fri.LastAccessTime.ToString() != null)
                                {
                                    listView1.Items[Count].SubItems.Add(fri.LastWriteTime.ToString());
                                }
                                else
                                {
                                    listView1.Items[Count].SubItems.Add(fri.CreationTime.ToString());
                                }
                                listView1.Items[Count].SubItems.Add(fri.Attributes.ToString());
                                listView1.Items[Count].SubItems.Add(fri.Length.ToString());
                                Count++;
                            }
                            //숨김 파일인 경우 보여주지 않는다
                            else
                            {
                                continue;
                            }

                            
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("예외 발생 : " + ex.Message);
                    }


                }
            }
        
        }

        //list의 tail을 찾아낸다
        private void find_last_node(LinkedList<String> path_list, LinkedListNode<String> head)
        {
            LinkedListNode<String> current = head;

            while(current.Next != null)
            {
                current = current.Next;
            }
            tail_node = current;
        }     

        //옮길 주소를 사용자가 직접 선택하는 경우
        //set1 버튼을 눌렀을 경우
        private void btn_set1_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2(this,1);
            frm2.ShowDialog();
        }
        //옮길 주소를 사용자가 직접 선택하는 경우
        //set2 버튼을 눌렀을 경우
        private void btn_set2_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2(this,2);
            frm2.ShowDialog();
        }
        //옮길 주소를 사용자가 직접 선택하는 경우
        //set3 버튼을 눌렀을 경우
        private void btn_set3_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2(this,3);
            frm2.ShowDialog();
        }

        //rank1 사용 하지 않기
        private void btn_disable1_Click(object sender, EventArgs e)
        {
            txt_rank1.Text = null;
            txt_path1.Text = null;
            cmb_list1.Items.Clear();
        }

        //rank2 사용하지 않기
        private void btn_disable2_Click(object sender, EventArgs e)
        {
            txt_rank2.Text = null;
            txt_path2.Text = null;
            cmb_list2.Items.Clear();
        }

        //rank3 사용하지 않기
        private void btn_disable3_Click(object sender, EventArgs e)
        {
            txt_rank3.Text = null;
            txt_path3.Text = null;
            cmb_list3.Items.Clear();
        }

        //옮김 주소를 자동적으로 계산하여 리스트로 보여주는 경우

        //(1) 버튼을 누르면 해당 디렉토리 안의 파일 및 폴더 명을 단여별로(띄어쓰기, _, -, .)로 나눠서 가장 많이 나온 단어(3순위까지)
        //    들을 rank1, rank2, rank3 txtbox에 올린다

        //(2) 해당 단어를 포함하는 디렉토리가 리스트 박스에 나타나진다  

        //고려해야 할 사항
        //대소문자 -> 대문자면 소문자로 바꿔서 한번에 소문자로 계산한다

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            //아무 디렉토리를 선택하지 않았을 경우
            if (txt_location.Text == "")
            {
                MessageBox.Show("Check any directory");
            }

            else
            {

                //계산하기 버튼을 누르면 rank1, rank2, rank3 textbox를 초기화 시켜준다
                txt_rank1.Text = null;
                txt_rank2.Text = null;
                txt_rank3.Text = null;

                //label들을 첫번째 화면으로 초기화
                lab_rank1.Text = "rank 1";
                lab_rank2.Text = "rank 2";
                lab_rank3.Text = "rank 3";

                //rank_window 창을 1로 초기화
                rank_window = 1;

                //word list dictionary를 초기화 시켜준다
                dict_word_list.Clear();
                sorted_list.Clear();

                //선택한 것의 경로 찾기 해야한다
                DirectoryInfo dir = new DirectoryInfo(txt_location.Text);

                
                //하부 디렉토리 보여주기
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {
                    //숨김 파일이 아닌 경우
                    if ((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                    
                        //이름을 가져왔으므로, 이것을 split(띄어쓰기, _, -, .)한다
                        String[] seperator = { ",", " ", "_", "-", "."};

                        //split해서 나온 단어들을 잠시 담을 string배열을 만든다
                        String[] strlist = dirItem.Name.Split(seperator, StringSplitOptions.RemoveEmptyEntries);                       

                        foreach(String s in strlist)
                        {
                            //dictionary 에 존재하는지를 확인한 후 확인하면 time을 1추가해주고
                            //dictionary 에 존재 하지 않으면, ADD해주고 time을 1로 해준다

                            //소문자로 단어를 변환
                            String word_lower = s.ToLower();
                           
                            //디렉토리에 이미 단어가 있는 경우 time만 +1 해준다
                            if (dict_word_list.ContainsKey(word_lower))
                            {
                                dict_word_list[word_lower]++;
                            }
                            
                            //디렉토리에 단어가 없는 경우 단어를 추가해주고 time을 1로 초기화 시켜준다
                            else
                            {
                                dict_word_list.Add(word_lower,1);
                            }                                                       
                        }                      

                    }

                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }

                //모든 파일을 가져온다
                FileInfo[] fishow = dir.GetFiles();
                int Count = 0;
                foreach (FileInfo fri in fishow)
                {

                    //숨김 파일이 아닌 경우
                    if ((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {                    

                        //이름을 가져왔으므로, 이것을 split(띄어쓰기, _, -, .)하여
                        //linked list에 존재하는지를 확인한 후 확인하면 time을 1추가해주고
                        //linked list에 존재 하지 않으면, ADD해주고 time을 1로 해준다

                        //이름을 가져왔으므로, 이것을 split(띄어쓰기, _, -, .)한다
                        String[] seperator = { ",", " ", "_", "-", "." ,"(",")","<",">"};

                        //split해서 나온 단어들을 잠시 담을 string배열을 만든다
                        //폴더와 달리 파일을 띄울때는 뒤에 확장자명이 뜨기 때문에, 확장자명을 제거한 파일명만을 이용한다
                        String[] strlist = Path.GetFileNameWithoutExtension(fri.Name).Split(seperator, StringSplitOptions.RemoveEmptyEntries);

                        foreach (String s in strlist)
                        {
                            //dictionary 에 존재하는지를 확인한 후 확인하면 time을 1추가해주고
                            //dictionary 에 존재 하지 않으면, ADD해주고 time을 1로 해준다

                            //소문자로 단어를 변환
                            String word_lower = s.ToLower();

                            //디렉토리에 이미 단어가 있는 경우 time만 +1 해준다
                            if (dict_word_list.ContainsKey(word_lower))
                            {
                                dict_word_list[word_lower]++;
                            }

                            //디렉토리에 단어가 없는 경우 단어를 추가해주고 time을 1로 초기화 시켜준다
                            else
                            {
                                dict_word_list.Add(word_lower, 1);
                            }
                        }

                        Count++;
                    }
                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }

              
                //dictionary를 time을 기준으로 내림차순으로 변환한 dictionary를 sorted_list에 넣어주기 위해 임시로 담아 둔 var
                var temp_list = from pair in dict_word_list
                            orderby pair.Value descending
                            select pair;

                //temp_list에 넣어두었던 값들을, sorted_list dictionary에 다시 넣어준다(내림차순)
                foreach (KeyValuePair<String, int> items in temp_list)
                {
                    sorted_list.Add(items.Key, items.Value);                          
                }

                // rank1, rank2, rank3 text box에 가장 많이 나온 순서대로 단어를 넣어준다

                //dictionary에 아무것도 없는 경우
                if(sorted_list.Count == 0)
                {
                    //아무것도 없는 경우에는 아무 일도 일어나지 않는다
                }

                //dictionary에 값이 하나만 있는 경우
                else if (sorted_list.Count == 1)
                {
                    txt_rank1.Text = sorted_list.Keys.ToList()[0];
                }

                //dictionary에 값이 두개만 있는 경우
                else if(sorted_list.Count == 2)
                {
                    txt_rank1.Text = sorted_list.Keys.ToList()[0];
                    txt_rank2.Text = sorted_list.Keys.ToList()[1];
                }

                //dictionary에 값이 세개 이상 있는 경우
                else
                {
                    //가장 많이 나온 1,2,3순위의 단어를 textbox rank1, rank2, rank3 에 올려준다
                    txt_rank1.Text = sorted_list.Keys.ToList()[0];
                    txt_rank2.Text = sorted_list.Keys.ToList()[1];
                    txt_rank3.Text = sorted_list.Keys.ToList()[2];
                }
            }

            //list box에 이제 해당 이름을 가진 디렉토리 들이 들어가야 한다



        }

        //버튼을 누르면 해당 폴더에 있는, 그리고 rank1, rank2, rank3 의 단어를 포함하고 있는 파일 및 폴더를 
        //각각의 auto_list에서 고른, 혹은 임의로 다른 폴더로 옮기고 싶을 시에는 path에 있는 경로로 파일 및 폴더를 옮긴다
        private void btn_move_Click(object sender, EventArgs e)
        {
            //첫번째 랭크에 값이 있을 경우
            if(txt_rank1.Text != null)
            {
                             
                //선택한 것의 경로 찾기 해야한다
                DirectoryInfo dir = new DirectoryInfo(txt_location.Text);

                //하부 디렉토리 보여주기
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {
                    //숨김 파일이 아닌 경우
                    if ((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                      
                        if (dirItem.Name.ToLower().Contains(txt_rank1.Text))
                        {

                            Console.WriteLine(dirItem.FullName);

                            string sourceFile = dirItem.FullName;
                            string destinationFile = txt_path1.Text;

                            Console.WriteLine(destinationFile);

                            System.IO.File.Move(sourceFile, destinationFile);

                        }

                    }

                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }

                //모든 파일을 가져온다
                FileInfo[] fishow = dir.GetFiles();
                
                foreach (FileInfo fri in fishow)
                {

                    //숨김 파일이 아닌 경우
                    if ((fri.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        
                        //확장자 명을 뗀 파일 이름
                        if (Path.GetFileNameWithoutExtension(fri.Name).ToLower().Contains(txt_rank1.Text))
                        {
                            //string sourceFile = fri.FullName;
                            //string destinationFile = txt_path1.Text;

                            //System.IO.File.Move(sourceFile, destinationFile);

                        }


                    }
                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }



            }

            //두번째 랭크에 값이 있을 경우
            if(txt_rank2.Text != null)
            {
                //선택한 것의 경로 찾기 해야한다
                DirectoryInfo dir = new DirectoryInfo(txt_location.Text);

                //하부 디렉토리 보여주기
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {
                    //숨김 파일이 아닌 경우
                    if ((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        if (dirItem.Name.ToLower().Contains(txt_rank1.Text))
                        {
                            //string sourceFile = dirItem.FullName;
                            //string destinationFile = txt_path2.Text;

                            //System.IO.File.Move(sourceFile, destinationFile);

                        }

                    }

                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }

                //모든 파일을 가져온다
                FileInfo[] fishow = dir.GetFiles();

                foreach (FileInfo fri in fishow)
                {

                    //확장자 명을 뗀 파일 이름
                    if (Path.GetFileNameWithoutExtension(fri.Name).ToLower().Contains(txt_rank1.Text))
                    {
                        //string sourceFile = fri.FullName;
                        //string destinationFile = txt_path2.Text;

                        //System.IO.File.Move(sourceFile, destinationFile);

                    }
                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }

            }

            //세번째 랭크에 값이 있을 경우
            if(txt_rank3.Text != null)
            {
                //선택한 것의 경로 찾기 해야한다
                DirectoryInfo dir = new DirectoryInfo(txt_location.Text);

                //하부 디렉토리 보여주기
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {
                    //숨김 파일이 아닌 경우
                    if ((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {

                        if (dirItem.Name.ToLower().Contains(txt_rank1.Text))
                        {
                            //string sourceFile = dirItem.FullName;
                            //string destinationFile = txt_path3.Text;

                            //System.IO.File.Move(sourceFile, destinationFile);

                        }
                    }

                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }

                //모든 파일을 가져온다
                FileInfo[] fishow = dir.GetFiles();

                foreach (FileInfo fri in fishow)
                {

                    //확장자 명을 뗀 파일 이름
                    if (Path.GetFileNameWithoutExtension(fri.Name).ToLower().Contains(txt_rank1.Text))
                    {
                        //string sourceFile = fri.FullName;
                        //string destinationFile = txt_path3.Text;

                        //System.IO.File.Move(sourceFile, destinationFile);

                    }
                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }
                }

            }

        }

        //새로고침 버튼을 누를 경우 초기화
        private void btn_refresh_Click(object sender, EventArgs e)
        {
            txt_location.Text = null;

            txt_rank1.Text = null;
            txt_path1.Text = null;

            txt_rank2.Text = null;
            txt_path2.Text = null;

            txt_rank3.Text = null;
            txt_path3.Text = null;

            lab_rank1.Text = "rank 1";
            lab_rank2.Text = "rank 2";
            lab_rank3.Text = "rank 3";

            rank_window = 1;

        }

        //previous 버튼을 눌렀을 경우
        //이전 순위의 목록들을 볼 수 있다
        private void btn_previous_Click(object sender, EventArgs e)
        {
            if (rank_window == 1)
            {
                //첫번째 순위 페이지 이므로 아무 행동도 일어나지 않는다
            }

            else
            {

                rank_window--;

                txt_rank1.Text = null;
                txt_rank2.Text = null;
                txt_rank3.Text = null;

                lab_rank1.Text = "rank " + ((rank_window * 3) - 2).ToString();
                lab_rank2.Text = "rank " + ((rank_window * 3) - 1).ToString();
                lab_rank3.Text = "rank " + (rank_window * 3).ToString();

                txt_path1.Text = null;
                txt_path2.Text = null;
                txt_path3.Text = null;


                //ranking winodw창에 값이 하나만 들어가 있는 경우
                if (sorted_list.Count == (rank_window*3) - 2)
                {
                    txt_rank1.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 2) - 1];
                }

                //ranking winodw창에 값이 두개만 들어가는 경우
                else if (sorted_list.Count == (rank_window*3)-1)
                {
                    txt_rank1.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 2) - 1];
                    txt_rank2.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 1) - 1];
                }

                //ranking window 창에 값이 세개 이상 들어갈 수 있는 경우
                else
                {
                    //가장 많이 나온 1,2,3순위의 단어를 textbox rank1, rank2, rank3 에 올려준다
                    txt_rank1.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 2) - 1];
                    txt_rank2.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 1) - 1];
                    txt_rank3.Text = sorted_list.Keys.ToList()[(rank_window * 3) - 1];
                }

                
                

            }


        }

        //next 버튼을 눌렀을 경우
        //다음 순위의 목록들을 볼 수 있다
        private void btn_next_Click(object sender, EventArgs e)
        {
            //sorted_list 최대 갯수를 넘어가는 경우
            if ((rank_window*3) >= sorted_list.Count)
            {
                //이 경우 아무 일도 일어나지 않는다
            }

            //가능한 경우
            else
            {

                rank_window++;

                txt_rank1.Text = null;
                txt_rank2.Text = null;
                txt_rank3.Text = null;

                lab_rank1.Text = "rank " + ((rank_window * 3) - 2).ToString();
                lab_rank2.Text = "rank " + ((rank_window * 3) - 1).ToString();
                lab_rank3.Text = "rank " + (rank_window * 3).ToString();

                txt_path1.Text = null;
                txt_path2.Text = null;
                txt_path3.Text = null;



                //ranking winodw창에 값이 하나만 들어가 있는 경우
                if (sorted_list.Count == (rank_window*3) - 2)
                {
                    txt_rank1.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 2) - 1];
                }

                //ranking winodw창에 값이 두개만 들어가는 경우
                else if (sorted_list.Count == (rank_window*3) - 1)
                {
                    txt_rank1.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 2) - 1];
                    txt_rank2.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 1) - 1];
                }

                //ranking window 창에 값이 세개 이상 들어갈 수 있는 경우
                else
                {
                    //가장 많이 나온 1,2,3순위의 단어를 textbox rank1, rank2, rank3 에 올려준다
                    txt_rank1.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 2) - 1];
                    txt_rank2.Text = sorted_list.Keys.ToList()[((rank_window * 3) - 1) - 1];
                    txt_rank3.Text = sorted_list.Keys.ToList()[(rank_window * 3) - 1];
                }

            }
        }

        //임의로 정한 path를 지운다
        private void btn_delete1_Click(object sender, EventArgs e)
        {
            txt_path1.Text = null;
        }
        //임의로 정한 path를 지운다
        private void btn_delete2_Click(object sender, EventArgs e)
        {
            txt_path2.Text = null;
        }
        //임의로 정한 path를 지운다
        private void btn_delete3_Click(object sender, EventArgs e)
        {
            txt_path3.Text = null;
        }

        //*****************************************************************************
        //*************이거 제대로 구현하지 못했음 해야한다****************************
        //*****************************************************************************

        //단어를 넣어주면 그 단어를 내포하고 있는 전체 디렉토리 안의 폴더를 리스트박스에 추가시켜준다
        //그러면 사용자는 거기서 고르기만 하면 된다
        //하나밖에 없으면 당연히 하나만 뜬다
        private void find_path(String word, int order)
        {
            //현재 로컬 컴퓨터에 존재하는 드라이브 정보 검색하여 트리노드에 추가
            DriveInfo[] allDrives = DriveInfo.GetDrives();
            

            //드라이브의 하위 폴더 추가
            foreach (DriveInfo drive in allDrives)
            {

                DirectoryInfo dir = new DirectoryInfo(drive.Name);

                //하부 디렉토리 보여주기
                foreach (DirectoryInfo dirItem in dir.GetDirectories())
                {
                    //숨김 파일이 아닌 경우
                    if ((dirItem.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                    {
                        //디렉토리 이름에 단어가 들어가 있는 경우
                        if (dirItem.Name.Contains(word))
                        {
                            if(order == 1)
                            {
                                cmb_list1.Items.Add(dirItem.FullName);
                            }
                            else if(order == 2)
                            {
                                cmb_list2.Items.Add(dirItem.FullName);
                            }
                            else if(order == 3)
                            {
                                cmb_list3.Items.Add(dirItem.FullName);
                            }
                            
                        }
                    }

                    //숨김 파일인 경우 보여주지 않는다
                    else
                    {
                        continue;
                    }

                }

            }




        }

    
    }
}
