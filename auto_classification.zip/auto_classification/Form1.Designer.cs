﻿namespace auto_classification
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btn_calculate = new System.Windows.Forms.Button();
            this.cmb_list3 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_list2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_list1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_location = new System.Windows.Forms.TextBox();
            this.lab_location = new System.Windows.Forms.Label();
            this.lab_path3 = new System.Windows.Forms.Label();
            this.txt_path3 = new System.Windows.Forms.TextBox();
            this.lab_path2 = new System.Windows.Forms.Label();
            this.txt_path2 = new System.Windows.Forms.TextBox();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.lab_pathSetting = new System.Windows.Forms.Label();
            this.btn_set3 = new System.Windows.Forms.Button();
            this.lab_rank3 = new System.Windows.Forms.Label();
            this.txt_rank3 = new System.Windows.Forms.TextBox();
            this.btn_set2 = new System.Windows.Forms.Button();
            this.lab_rank2 = new System.Windows.Forms.Label();
            this.txt_rank2 = new System.Windows.Forms.TextBox();
            this.lab_path1 = new System.Windows.Forms.Label();
            this.txt_path1 = new System.Windows.Forms.TextBox();
            this.btn_set1 = new System.Windows.Forms.Button();
            this.lab_rank1 = new System.Windows.Forms.Label();
            this.txt_rank1 = new System.Windows.Forms.TextBox();
            this.btn_move = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_after = new System.Windows.Forms.Button();
            this.cboListViewMode = new System.Windows.Forms.ComboBox();
            this.txtCurPath = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.btn_disable1 = new System.Windows.Forms.Button();
            this.btn_disable2 = new System.Windows.Forms.Button();
            this.btn_disable3 = new System.Windows.Forms.Button();
            this.btn_previous = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_delete1 = new System.Windows.Forms.Button();
            this.btn_delete2 = new System.Windows.Forms.Button();
            this.btn_delete3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btn_delete3);
            this.splitContainer1.Panel2.Controls.Add(this.btn_delete2);
            this.splitContainer1.Panel2.Controls.Add(this.btn_delete1);
            this.splitContainer1.Panel2.Controls.Add(this.btn_next);
            this.splitContainer1.Panel2.Controls.Add(this.btn_previous);
            this.splitContainer1.Panel2.Controls.Add(this.btn_disable3);
            this.splitContainer1.Panel2.Controls.Add(this.btn_disable2);
            this.splitContainer1.Panel2.Controls.Add(this.btn_disable1);
            this.splitContainer1.Panel2.Controls.Add(this.btn_calculate);
            this.splitContainer1.Panel2.Controls.Add(this.cmb_list3);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.cmb_list2);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.cmb_list1);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.txt_location);
            this.splitContainer1.Panel2.Controls.Add(this.lab_location);
            this.splitContainer1.Panel2.Controls.Add(this.lab_path3);
            this.splitContainer1.Panel2.Controls.Add(this.txt_path3);
            this.splitContainer1.Panel2.Controls.Add(this.lab_path2);
            this.splitContainer1.Panel2.Controls.Add(this.txt_path2);
            this.splitContainer1.Panel2.Controls.Add(this.btn_refresh);
            this.splitContainer1.Panel2.Controls.Add(this.lab_pathSetting);
            this.splitContainer1.Panel2.Controls.Add(this.btn_set3);
            this.splitContainer1.Panel2.Controls.Add(this.lab_rank3);
            this.splitContainer1.Panel2.Controls.Add(this.txt_rank3);
            this.splitContainer1.Panel2.Controls.Add(this.btn_set2);
            this.splitContainer1.Panel2.Controls.Add(this.lab_rank2);
            this.splitContainer1.Panel2.Controls.Add(this.txt_rank2);
            this.splitContainer1.Panel2.Controls.Add(this.lab_path1);
            this.splitContainer1.Panel2.Controls.Add(this.txt_path1);
            this.splitContainer1.Panel2.Controls.Add(this.btn_set1);
            this.splitContainer1.Panel2.Controls.Add(this.lab_rank1);
            this.splitContainer1.Panel2.Controls.Add(this.txt_rank1);
            this.splitContainer1.Panel2.Controls.Add(this.btn_move);
            this.splitContainer1.Panel2.Controls.Add(this.btn_back);
            this.splitContainer1.Panel2.Controls.Add(this.btn_after);
            this.splitContainer1.Panel2.Controls.Add(this.cboListViewMode);
            this.splitContainer1.Panel2.Controls.Add(this.txtCurPath);
            this.splitContainer1.Panel2.Controls.Add(this.listView1);
            this.splitContainer1.Size = new System.Drawing.Size(1236, 473);
            this.splitContainer1.SplitterDistance = 265;
            this.splitContainer1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // treeView1
            // 
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(0, 46);
            this.treeView1.Name = "treeView1";
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(260, 415);
            this.treeView1.TabIndex = 0;
            this.treeView1.BeforeCollapse += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView1_BeforeCollapse_1);
            this.treeView1.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView1_BeforeExpand_1);
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick_1);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "hard_drive_windows_2.ico");
            this.imageList1.Images.SetKeyName(1, "hard_drive.ico");
            this.imageList1.Images.SetKeyName(2, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(3, "opened_folder.ico");
            this.imageList1.Images.SetKeyName(4, "Hopstarter-Sleek-Xp_Basic-Document-Blank.ico");
            // 
            // btn_calculate
            // 
            this.btn_calculate.Font = new System.Drawing.Font("굴림", 11F);
            this.btn_calculate.Location = new System.Drawing.Point(639, 433);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(75, 28);
            this.btn_calculate.TabIndex = 40;
            this.btn_calculate.Text = "Calculate";
            this.btn_calculate.UseVisualStyleBackColor = true;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // cmb_list3
            // 
            this.cmb_list3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_list3.FormattingEnabled = true;
            this.cmb_list3.Location = new System.Drawing.Point(681, 327);
            this.cmb_list3.Name = "cmb_list3";
            this.cmb_list3.Size = new System.Drawing.Size(174, 20);
            this.cmb_list3.TabIndex = 39;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 11F);
            this.label4.Location = new System.Drawing.Point(613, 332);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 15);
            this.label4.TabIndex = 38;
            this.label4.Text = "auto_list";
            // 
            // cmb_list2
            // 
            this.cmb_list2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_list2.FormattingEnabled = true;
            this.cmb_list2.Location = new System.Drawing.Point(681, 227);
            this.cmb_list2.Name = "cmb_list2";
            this.cmb_list2.Size = new System.Drawing.Size(174, 20);
            this.cmb_list2.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 11F);
            this.label3.Location = new System.Drawing.Point(613, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 15);
            this.label3.TabIndex = 36;
            this.label3.Text = "auto_list";
            // 
            // cmb_list1
            // 
            this.cmb_list1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_list1.FormattingEnabled = true;
            this.cmb_list1.Location = new System.Drawing.Point(681, 129);
            this.cmb_list1.Name = "cmb_list1";
            this.cmb_list1.Size = new System.Drawing.Size(174, 20);
            this.cmb_list1.TabIndex = 35;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 11F);
            this.label2.Location = new System.Drawing.Point(613, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 15);
            this.label2.TabIndex = 34;
            this.label2.Text = "auto_list";
            // 
            // txt_location
            // 
            this.txt_location.Location = new System.Drawing.Point(681, 57);
            this.txt_location.Name = "txt_location";
            this.txt_location.ReadOnly = true;
            this.txt_location.Size = new System.Drawing.Size(274, 21);
            this.txt_location.TabIndex = 32;
            // 
            // lab_location
            // 
            this.lab_location.AutoSize = true;
            this.lab_location.Font = new System.Drawing.Font("굴림", 11F);
            this.lab_location.Location = new System.Drawing.Point(611, 57);
            this.lab_location.Name = "lab_location";
            this.lab_location.Size = new System.Drawing.Size(59, 15);
            this.lab_location.TabIndex = 31;
            this.lab_location.Text = "location";
            // 
            // lab_path3
            // 
            this.lab_path3.AutoSize = true;
            this.lab_path3.Font = new System.Drawing.Font("굴림", 11F);
            this.lab_path3.Location = new System.Drawing.Point(640, 356);
            this.lab_path3.Name = "lab_path3";
            this.lab_path3.Size = new System.Drawing.Size(35, 15);
            this.lab_path3.TabIndex = 30;
            this.lab_path3.Text = "path";
            // 
            // txt_path3
            // 
            this.txt_path3.Location = new System.Drawing.Point(681, 353);
            this.txt_path3.Name = "txt_path3";
            this.txt_path3.ReadOnly = true;
            this.txt_path3.Size = new System.Drawing.Size(174, 21);
            this.txt_path3.TabIndex = 29;
            this.txt_path3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lab_path2
            // 
            this.lab_path2.AutoSize = true;
            this.lab_path2.Font = new System.Drawing.Font("굴림", 11F);
            this.lab_path2.Location = new System.Drawing.Point(640, 256);
            this.lab_path2.Name = "lab_path2";
            this.lab_path2.Size = new System.Drawing.Size(35, 15);
            this.lab_path2.TabIndex = 28;
            this.lab_path2.Text = "path";
            // 
            // txt_path2
            // 
            this.txt_path2.Location = new System.Drawing.Point(681, 253);
            this.txt_path2.Name = "txt_path2";
            this.txt_path2.ReadOnly = true;
            this.txt_path2.Size = new System.Drawing.Size(174, 21);
            this.txt_path2.TabIndex = 27;
            this.txt_path2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_refresh
            // 
            this.btn_refresh.Location = new System.Drawing.Point(827, 433);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(75, 28);
            this.btn_refresh.TabIndex = 26;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // lab_pathSetting
            // 
            this.lab_pathSetting.AutoSize = true;
            this.lab_pathSetting.Font = new System.Drawing.Font("굴림", 15F);
            this.lab_pathSetting.Location = new System.Drawing.Point(712, 20);
            this.lab_pathSetting.Name = "lab_pathSetting";
            this.lab_pathSetting.Size = new System.Drawing.Size(113, 20);
            this.lab_pathSetting.TabIndex = 25;
            this.lab_pathSetting.Text = "Path Setting";
            // 
            // btn_set3
            // 
            this.btn_set3.Location = new System.Drawing.Point(861, 354);
            this.btn_set3.Name = "btn_set3";
            this.btn_set3.Size = new System.Drawing.Size(38, 23);
            this.btn_set3.TabIndex = 21;
            this.btn_set3.Text = "set";
            this.btn_set3.UseVisualStyleBackColor = true;
            this.btn_set3.Click += new System.EventHandler(this.btn_set3_Click);
            // 
            // lab_rank3
            // 
            this.lab_rank3.AutoSize = true;
            this.lab_rank3.Font = new System.Drawing.Font("굴림", 11F);
            this.lab_rank3.Location = new System.Drawing.Point(628, 303);
            this.lab_rank3.Name = "lab_rank3";
            this.lab_rank3.Size = new System.Drawing.Size(47, 15);
            this.lab_rank3.TabIndex = 20;
            this.lab_rank3.Text = "rank 3";
            // 
            // txt_rank3
            // 
            this.txt_rank3.Location = new System.Drawing.Point(681, 300);
            this.txt_rank3.Name = "txt_rank3";
            this.txt_rank3.ReadOnly = true;
            this.txt_rank3.Size = new System.Drawing.Size(174, 21);
            this.txt_rank3.TabIndex = 19;
            this.txt_rank3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_set2
            // 
            this.btn_set2.Location = new System.Drawing.Point(861, 251);
            this.btn_set2.Name = "btn_set2";
            this.btn_set2.Size = new System.Drawing.Size(38, 23);
            this.btn_set2.TabIndex = 15;
            this.btn_set2.Text = "set";
            this.btn_set2.UseVisualStyleBackColor = true;
            this.btn_set2.Click += new System.EventHandler(this.btn_set2_Click);
            // 
            // lab_rank2
            // 
            this.lab_rank2.AutoSize = true;
            this.lab_rank2.Font = new System.Drawing.Font("굴림", 11F);
            this.lab_rank2.Location = new System.Drawing.Point(628, 203);
            this.lab_rank2.Name = "lab_rank2";
            this.lab_rank2.Size = new System.Drawing.Size(47, 15);
            this.lab_rank2.TabIndex = 14;
            this.lab_rank2.Text = "rank 2";
            // 
            // txt_rank2
            // 
            this.txt_rank2.Location = new System.Drawing.Point(681, 200);
            this.txt_rank2.Name = "txt_rank2";
            this.txt_rank2.ReadOnly = true;
            this.txt_rank2.Size = new System.Drawing.Size(174, 21);
            this.txt_rank2.TabIndex = 13;
            this.txt_rank2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lab_path1
            // 
            this.lab_path1.AutoSize = true;
            this.lab_path1.Font = new System.Drawing.Font("굴림", 11F);
            this.lab_path1.Location = new System.Drawing.Point(640, 158);
            this.lab_path1.Name = "lab_path1";
            this.lab_path1.Size = new System.Drawing.Size(35, 15);
            this.lab_path1.TabIndex = 11;
            this.lab_path1.Text = "path";
            // 
            // txt_path1
            // 
            this.txt_path1.Location = new System.Drawing.Point(681, 155);
            this.txt_path1.Name = "txt_path1";
            this.txt_path1.ReadOnly = true;
            this.txt_path1.Size = new System.Drawing.Size(174, 21);
            this.txt_path1.TabIndex = 10;
            this.txt_path1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_set1
            // 
            this.btn_set1.Location = new System.Drawing.Point(861, 155);
            this.btn_set1.Name = "btn_set1";
            this.btn_set1.Size = new System.Drawing.Size(38, 23);
            this.btn_set1.TabIndex = 9;
            this.btn_set1.Text = "set";
            this.btn_set1.UseVisualStyleBackColor = true;
            this.btn_set1.Click += new System.EventHandler(this.btn_set1_Click);
            // 
            // lab_rank1
            // 
            this.lab_rank1.AutoSize = true;
            this.lab_rank1.Font = new System.Drawing.Font("굴림", 11F);
            this.lab_rank1.Location = new System.Drawing.Point(628, 102);
            this.lab_rank1.Name = "lab_rank1";
            this.lab_rank1.Size = new System.Drawing.Size(47, 15);
            this.lab_rank1.TabIndex = 8;
            this.lab_rank1.Text = "rank 1";
            // 
            // txt_rank1
            // 
            this.txt_rank1.Location = new System.Drawing.Point(681, 99);
            this.txt_rank1.Name = "txt_rank1";
            this.txt_rank1.ReadOnly = true;
            this.txt_rank1.Size = new System.Drawing.Size(174, 21);
            this.txt_rank1.TabIndex = 7;
            this.txt_rank1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_move
            // 
            this.btn_move.Font = new System.Drawing.Font("굴림", 11F);
            this.btn_move.Location = new System.Drawing.Point(735, 433);
            this.btn_move.Name = "btn_move";
            this.btn_move.Size = new System.Drawing.Size(75, 28);
            this.btn_move.TabIndex = 6;
            this.btn_move.Text = "Move";
            this.btn_move.UseVisualStyleBackColor = true;
            this.btn_move.Click += new System.EventHandler(this.btn_move_Click);
            // 
            // btn_back
            // 
            this.btn_back.Image = global::auto_classification.Properties.Resources.go_after1;
            this.btn_back.Location = new System.Drawing.Point(8, 20);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(29, 20);
            this.btn_back.TabIndex = 5;
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_after
            // 
            this.btn_after.Image = global::auto_classification.Properties.Resources.go_after;
            this.btn_after.Location = new System.Drawing.Point(43, 19);
            this.btn_after.Name = "btn_after";
            this.btn_after.Size = new System.Drawing.Size(29, 20);
            this.btn_after.TabIndex = 4;
            this.btn_after.UseVisualStyleBackColor = true;
            this.btn_after.Click += new System.EventHandler(this.btn_after_Click);
            // 
            // cboListViewMode
            // 
            this.cboListViewMode.FormattingEnabled = true;
            this.cboListViewMode.Location = new System.Drawing.Point(478, 20);
            this.cboListViewMode.Name = "cboListViewMode";
            this.cboListViewMode.Size = new System.Drawing.Size(112, 20);
            this.cboListViewMode.TabIndex = 2;
            this.cboListViewMode.SelectedIndexChanged += new System.EventHandler(this.cboListViewMode_SelectedIndexChanged);
            // 
            // txtCurPath
            // 
            this.txtCurPath.Location = new System.Drawing.Point(78, 19);
            this.txtCurPath.Name = "txtCurPath";
            this.txtCurPath.ReadOnly = true;
            this.txtCurPath.Size = new System.Drawing.Size(394, 21);
            this.txtCurPath.TabIndex = 1;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.LargeImageList = this.imageList2;
            this.listView1.Location = new System.Drawing.Point(8, 46);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(582, 415);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.Click += new System.EventHandler(this.listView1_Click);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick_1);
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "hard_drive_windows_2.ico");
            this.imageList2.Images.SetKeyName(1, "hard_drive.ico");
            this.imageList2.Images.SetKeyName(2, "folderopened_yellow.ico");
            this.imageList2.Images.SetKeyName(3, "opened_folder.ico");
            this.imageList2.Images.SetKeyName(4, "Hopstarter-Sleek-Xp_Basic-Document-Blank.ico");
            // 
            // btn_disable1
            // 
            this.btn_disable1.Location = new System.Drawing.Point(861, 97);
            this.btn_disable1.Name = "btn_disable1";
            this.btn_disable1.Size = new System.Drawing.Size(54, 23);
            this.btn_disable1.TabIndex = 41;
            this.btn_disable1.Text = "disable";
            this.btn_disable1.UseVisualStyleBackColor = true;
            this.btn_disable1.Click += new System.EventHandler(this.btn_disable1_Click);
            // 
            // btn_disable2
            // 
            this.btn_disable2.Location = new System.Drawing.Point(861, 198);
            this.btn_disable2.Name = "btn_disable2";
            this.btn_disable2.Size = new System.Drawing.Size(54, 23);
            this.btn_disable2.TabIndex = 42;
            this.btn_disable2.Text = "disable";
            this.btn_disable2.UseVisualStyleBackColor = true;
            this.btn_disable2.Click += new System.EventHandler(this.btn_disable2_Click);
            // 
            // btn_disable3
            // 
            this.btn_disable3.Location = new System.Drawing.Point(861, 298);
            this.btn_disable3.Name = "btn_disable3";
            this.btn_disable3.Size = new System.Drawing.Size(54, 23);
            this.btn_disable3.TabIndex = 43;
            this.btn_disable3.Text = "disable";
            this.btn_disable3.UseVisualStyleBackColor = true;
            this.btn_disable3.Click += new System.EventHandler(this.btn_disable3_Click);
            // 
            // btn_previous
            // 
            this.btn_previous.Location = new System.Drawing.Point(681, 392);
            this.btn_previous.Name = "btn_previous";
            this.btn_previous.Size = new System.Drawing.Size(75, 23);
            this.btn_previous.TabIndex = 44;
            this.btn_previous.Text = "previous";
            this.btn_previous.UseVisualStyleBackColor = true;
            this.btn_previous.Click += new System.EventHandler(this.btn_previous_Click);
            // 
            // btn_next
            // 
            this.btn_next.Location = new System.Drawing.Point(780, 392);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(75, 23);
            this.btn_next.TabIndex = 45;
            this.btn_next.Text = "next";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_delete1
            // 
            this.btn_delete1.Location = new System.Drawing.Point(905, 155);
            this.btn_delete1.Name = "btn_delete1";
            this.btn_delete1.Size = new System.Drawing.Size(50, 23);
            this.btn_delete1.TabIndex = 46;
            this.btn_delete1.Text = "delete";
            this.btn_delete1.UseVisualStyleBackColor = true;
            this.btn_delete1.Click += new System.EventHandler(this.btn_delete1_Click);
            // 
            // btn_delete2
            // 
            this.btn_delete2.Location = new System.Drawing.Point(905, 251);
            this.btn_delete2.Name = "btn_delete2";
            this.btn_delete2.Size = new System.Drawing.Size(50, 23);
            this.btn_delete2.TabIndex = 47;
            this.btn_delete2.Text = "delete";
            this.btn_delete2.UseVisualStyleBackColor = true;
            this.btn_delete2.Click += new System.EventHandler(this.btn_delete2_Click);
            // 
            // btn_delete3
            // 
            this.btn_delete3.Location = new System.Drawing.Point(905, 354);
            this.btn_delete3.Name = "btn_delete3";
            this.btn_delete3.Size = new System.Drawing.Size(50, 23);
            this.btn_delete3.TabIndex = 48;
            this.btn_delete3.Text = "delete";
            this.btn_delete3.UseVisualStyleBackColor = true;
            this.btn_delete3.Click += new System.EventHandler(this.btn_delete3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1236, 473);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ComboBox cboListViewMode;
        private System.Windows.Forms.TextBox txtCurPath;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_after;
        private System.Windows.Forms.Button btn_move;
        private System.Windows.Forms.Button btn_set1;
        private System.Windows.Forms.Label lab_rank1;
        private System.Windows.Forms.TextBox txt_rank1;
        private System.Windows.Forms.Button btn_set3;
        private System.Windows.Forms.Label lab_rank3;
        private System.Windows.Forms.TextBox txt_rank3;
        private System.Windows.Forms.Button btn_set2;
        private System.Windows.Forms.Label lab_rank2;
        private System.Windows.Forms.TextBox txt_rank2;
        private System.Windows.Forms.Label lab_path1;
        private System.Windows.Forms.Label lab_pathSetting;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.Label lab_path3;
        private System.Windows.Forms.Label lab_path2;
        private System.Windows.Forms.TextBox txt_location;
        private System.Windows.Forms.Label lab_location;
        public System.Windows.Forms.TextBox txt_path1;
        public System.Windows.Forms.TextBox txt_path3;
        public System.Windows.Forms.TextBox txt_path2;
        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.ComboBox cmb_list3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmb_list2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_list1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_disable3;
        private System.Windows.Forms.Button btn_disable2;
        private System.Windows.Forms.Button btn_disable1;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_previous;
        private System.Windows.Forms.Button btn_delete3;
        private System.Windows.Forms.Button btn_delete2;
        private System.Windows.Forms.Button btn_delete1;
    }
}

